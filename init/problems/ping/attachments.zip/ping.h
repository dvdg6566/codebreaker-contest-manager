#include <bits/stdc++.h>

int rabbit(int P);

int ping(int x);
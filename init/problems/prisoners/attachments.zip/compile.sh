#!/bin/sh

g++ -O2 main.cpp prisoner.cpp swapper.cpp -o prisoners

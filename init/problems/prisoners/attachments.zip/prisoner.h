#ifndef __PRISONER_H__
#define __PRISONER_H__

int openBox(int x);
void prisoner(int N, int id);

#endif /* __PRISONER_H__ */

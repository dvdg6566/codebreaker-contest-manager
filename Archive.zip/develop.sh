sudo service nginx stop
sudo python3 app.py develop

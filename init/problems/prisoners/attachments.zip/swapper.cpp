#include "swapper.h"

void swapper(int N, int boxes[]) {
	/* ... */
}

#include "ping.h"
#include <bits/stdc++.h>

int rabbit(int P){
	return 1;
}
GMAIL_ADDRESS = 'codebreakerjudge@gmail.com'
GMAIL_PASSWORD = 'lqiodmbvwtldaajr'
FLASK_SECRET_KEY = '1821vulpixhh'
GOOGLE_CLIENT_SECRET = "qhUQtSCforsptlmfuVQDXPuc"
API_KEY = "97dcc1f78f096f3cce9e4372135b14592bc51"
AWS_COGNITO_USER_POOL_CLIENT_SECRET = "1dhvf4e21cbaf27la2ltegaju59da2jlmh2ilc4og3ja05m8gpsp"
sudo systemctl stop apache2
sudo systemctl restart nginx
sudo python3 app.py deploy

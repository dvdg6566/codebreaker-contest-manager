#ifndef __SWAPPER_H__
#define __SWAPPER_H__

void swapKeys(int a, int b);
void swapper(int N, int boxes[]);

#endif /* __SWAPPER_H__ */

#include "prisoner.h"

void prisoner(int N, int id) {
	/* ... */
}
